

  window.onload = function(){ 
    document.getElementById('go').onclick = function() {
        window.location.href = 'calendar.html';
      };
    
      document.getElementById('dan').onclick = function() {
        window.location.href = 'about-us.html';
      };

      document.getElementById('logotype').onclick = function() {
        window.location.href = 'index.html';
      };

      document.getElementById('inst').onclick = function() {
        window.location.href = 'https://instagram.com/wavehub.ro?utm_medium=copy_link';
      };
};